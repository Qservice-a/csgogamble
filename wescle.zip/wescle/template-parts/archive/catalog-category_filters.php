<?php
global $wp_query;
?>
<div class="category-catalog-results">
    <div class="category-catalog-results__title"><?php echo wescle_catalog_title_results( $wp_query->found_posts ); ?></div>
	<?php if ( $wp_query->found_posts ) { ?>
        <form class="catalog-ordering" method="get">
			<?php wescle_query_string_form_fields( [ 'orderby' ] ); ?>
			<?php
			$orderby                 = $_GET['orderby'] ?? '';
			$catalog_orderby_options = [
				''           => __( 'Сортировка', 'wescle' ),
				'top'        => __( 'Топ предложения', 'wescle' ),
				'popularity' => __( 'Популярное', 'wescle' ),
				'price'      => __( 'Цена (сначала дешевые)', 'wescle' ),
			];
			?>
            <select name="orderby">
				<?php foreach ( $catalog_orderby_options as $id => $name ) : ?>
                    <option value="<?php echo esc_attr( $id ); ?>" <?php selected( $orderby, $id ); ?>><?php echo esc_html( $name ); ?></option>
				<?php endforeach; ?>
            </select>
        </form>
	<?php } ?>
</div>