<?php if ( get_theme_mod( 'header_search', true ) ) { ?>
    <div class="header__search-form is-hide">
        <button class="btn-close" type="button">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 24 24">
                <path fill="#626262" d="M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29l-4.3 4.29a1 1 0 0 0 0 1.42a1 1 0 0 0 1.42 0l4.29-4.3l4.29 4.3a1 1 0 0 0 1.42 0a1 1 0 0 0 0-1.42z"></path>
            </svg>
        </button>
        <form class="form-search" id="form-search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<?php wescle_search_post_type(); ?>
            <input class="form-search__input input"
                   type="search"
                   placeholder="<?php echo Helper::get_default_theme_data( 'search_placeholder' ) ?>"
                   data-placeholder="<?php echo Helper::get_default_theme_data( 'search_placeholder' ) ?>"
                   data-placeholder_voice="<?php echo Helper::get_default_theme_data( 'search_placeholder_voice' ) ?>"
                   value="<?php echo get_search_query(); ?>"
                   name="s">
	        <?php if ( get_theme_mod( 'header_search_voice', true ) ) { ?>
                <button class="_voice-trigger" id="voice-trigger" type="button" style="opacity: 0;">
                    <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 1024 1024">
                        <path fill="currentColor" d="M512 128a128 128 0 0 0-128 128v256a128 128 0 1 0 256 0V256a128 128 0 0 0-128-128zm0-64a192 192 0 0 1 192 192v256a192 192 0 1 1-384 0V256A192 192 0 0 1 512 64zm-32 832v-64a288 288 0 0 1-288-288v-32a32 32 0 0 1 64 0v32a224 224 0 0 0 224 224h64a224 224 0 0 0 224-224v-32a32 32 0 1 1 64 0v32a288 288 0 0 1-288 288v64h64a32 32 0 1 1 0 64H416a32 32 0 1 1 0-64h64z"></path>
                    </svg>
                </button>
	        <?php } ?>
            <button class="form-search__btn" type="submit">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 24 24">
                    <path d="M10 18a7.952 7.952 0 0 0 4.897-1.688l4.396 4.396l1.414-1.414l-4.396-4.396A7.952 7.952 0 0 0 18 10c0-4.411-3.589-8-8-8s-8 3.589-8 8s3.589 8 8 8zm0-14c3.309 0 6 2.691 6 6s-2.691 6-6 6s-6-2.691-6-6s2.691-6 6-6z" fill="#626262"></path>
                </svg>
            </button>
	        <?php if ( get_theme_mod( 'header_search', true ) && get_theme_mod( 'header_search_ajax', false ) ) { ?>
                <button type="button" class="livesearch-preloader"></button>
	        <?php } ?>
        </form>
	    <?php
	    if ( get_theme_mod( 'header_search', true ) && get_theme_mod( 'header_search_ajax', false ) ) {
		    get_template_part( 'template-parts/header/navigation', 'search-live' );
	    }
	    ?>
    </div>
<?php } ?>