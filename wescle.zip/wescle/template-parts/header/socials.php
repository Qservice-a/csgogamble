<?php
get_template_part( 'template-parts/footer/socials', null, [ 'ul_class' => 'header__socials' ] );
