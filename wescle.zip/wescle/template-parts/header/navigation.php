<?php
if ( Helper::is_store( 'header' ) ) {
	if ( get_theme_mod( 'header_store_menu', true ) ) {
		get_template_part( 'template-parts/header/navigation-vertical' );
	}
}

if ( ! has_nav_menu( 'header_menu' ) ) {
	return;
}

require_once get_template_directory() . '/includes/app/MenuTopWalker.php';
?>
<ul class="navigation__list" id="nav-list">
	<?php
	wp_nav_menu(
		array(
			'container'      => '',
			'items_wrap'     => '%3$s',
			'theme_location' => 'header_menu',
			'walker'         => new MenuTopWalker()
		)
	);
	?>
</ul>
<ul class="navigation__list navigation-list-yet hide">
    <li class="navigation__item"><a class="navigation__link"><span></span><span></span><span></span></a>
        <ul class="navigation__sublist navigation-sublist-yet"></ul>
    </li>
</ul>