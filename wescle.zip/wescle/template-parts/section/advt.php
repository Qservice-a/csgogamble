<?php
$args           = get_query_var( 'template_args' );
$show_container = true;
if ( isset( $args['container'] ) && $args['container'] == false ) {
	$show_container = false;
}

$code = $args['code'];
if ( $code ) {
	if ( $show_container ) {
		$markup = '<div class="container"><div class="row"><div class="col-12">%s</div></div></div>';
	}
	else {
		$markup = '%s';
	}
	?>
    <div class="bonus">
		<?php printf( $markup, do_shortcode( $code ) ); ?>
    </div>
	<?php
}

