<?php
$addit_class = get_theme_mod( 'footer_block_classes_copyright' );
?>
<div class="footer__copyright <?php echo $addit_class; ?>">
	<?php
	$copyright = str_replace( '#year#', current_time( 'Y' ), get_theme_mod( 'copyright', '© #year# ' . get_bloginfo( 'name' ) ) );
	echo $copyright;
	?>
	<?php if ( get_theme_mod( 'partner_enable', true ) ) : ?>
        <!--noindex-->
        <div class="footer__partner">
			<?php
			echo WsclPartnerShip::get_link( [
				'prefix'  => get_theme_mod( 'partner_prefix' ),
				'postfix' => get_theme_mod( 'partner_postfix' ),
			] );
			?>
        </div>
        <!--/noindex-->
	<?php endif; ?>
</div>