<?php
if ( $cf_id = get_theme_mod( 'footer_subscribe_cf7', 0 ) ) { ?>
	<?php if ( class_exists( 'WPCF7_Mail' ) ) { ?>
        <div class="footer__top">
            <div class="footer__form form-subscribe">
                <label class="form-subscribe__label">
                    <svg xmlns="http://www.w3.org/2000/svg" width="70" height="30" viewbox="0 0 70 30">
                        <defs>
                            <style>
                              .fcls-1 {
                                fill: #fff;
                                fill-rule: evenodd
                              }
                            </style>
                        </defs>
                        <path class="fcls-1"
                              d="M32,0H65a4,4,0,0,1,4,4V26a4,4,0,0,1-4,4H32a4,4,0,0,1-4-4V4A4,4,0,0,1,32,0Zm0,2H65a2,2,0,0,1,2,2V26a2,2,0,0,1-2,2H32a2,2,0,0,1-2-2V4A2,2,0,0,1,32,2ZM45.672,18.834L32.134,5.3A1.992,1.992,0,0,1,33.7,4.031L47.086,17.419a2,2,0,0,0,2.828,0L63.3,4.031A1.992,1.992,0,0,1,64.866,5.3L51.328,18.834A4,4,0,0,1,45.672,18.834ZM7,8H21a1,1,0,0,1,1,1h0a1,1,0,0,1-1,1H7A1,1,0,0,1,6,9H6A1,1,0,0,1,7,8ZM1,14H15a1,1,0,0,1,1,1h0a1,1,0,0,1-1,1H1a1,1,0,0,1-1-1H0A1,1,0,0,1,1,14Zm6,6H21a1,1,0,0,1,1,1h0a1,1,0,0,1-1,1H7a1,1,0,0,1-1-1H6A1,1,0,0,1,7,20Z"></path>
                    </svg>
                    <span><?php echo get_theme_mod( 'footer_subscribe_text', Helper::get_default_theme_data( 'footer_subscribe_text' ) ); ?></span>
                </label>
	            <?php echo do_shortcode( '[contact-form-7 id="' . $cf_id . '"]' ); ?>
            </div>
        </div>
	<?php } ?>
<?php } ?>