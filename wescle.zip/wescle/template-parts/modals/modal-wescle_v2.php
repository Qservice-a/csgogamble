<?php
$modal_data = $args['data'];
?>
<div class="popup_wescle <?php echo $modal_data['class']; ?> modal-box modal-v2 is-hide" <?php echo $modal_data['atts']; ?>>
    <div class="<?php echo $modal_data['overlay']; ?>"></div>
    <div class="popup_wescle__body modal-box__body modal-v2__body">
        <button class="popup_wescle__close modal-box__close" type="button">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 24 24">
                <path fill="#626262" d="M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29l-4.3 4.29a1 1 0 0 0 0 1.42a1 1 0 0 0 1.42 0l4.29-4.3l4.29 4.3a1 1 0 0 0 1.42 0a1 1 0 0 0 0-1.42z"></path>
            </svg>
        </button>
		<?php if ( $modal_data['image_id'] ) { ?>
            <div class="modal-v2__img">
				<?php echo wp_get_attachment_image( $modal_data['image_id'], 'medium_large' ); ?>
            </div>
	    <?php } ?>
        <div class="modal-v2__content">
            <div class="modal-v2__title"><?php echo $modal_data['title']; ?></div>
	        <?php if ( $modal_data['text'] ) { ?>
                <div class="modal-v2__description"><?php echo $modal_data['text']; ?></div>
	        <?php } ?>
	        <?php
	        if ( $modal_data['cf7'] ) {
		        echo do_shortcode( '[contact-form-7 id="' . $modal_data['cf7'] . '" html_class="modal-v2__form"]' );
	        }
	        ?>
        </div>
    </div>
</div>
