<?php
$cf7_id = 0;
if ( Helper::isset_block_content( 'wescle-tariffs' ) ) {
	$parse_content = parse_blocks( $post->post_content );
	foreach ( $parse_content as $item ) {
		if ( $item['blockName'] == 'wescle-blocks/wescle-tariffs' ) {
			if ( isset( $item['attrs']['selectedForm'] ) ) {
				$cf7_id = $item['attrs']['selectedForm'];
			}
            elseif ( isset( $item['attrs']['form'] ) ) {
				$cf7_id = $item['attrs']['form'];
			}
		}
	}
}
elseif ( Helper::is_frontpage_assets() && get_theme_mod( 'home_tariff_enabled', false ) && get_theme_mod( 'home_tariff_enabled_home', true ) ) {
	$cf7_id = get_theme_mod( 'home_tariff_cf7', '' );
}
if ( intval( $cf7_id ) ) {
	?>
    <div class="popup_wescle popup_wescle_modal-order_tariff modal-box modal-call is-hide" id="modal-order_tariff" style="opacity: 0">
        <div class="modal-box__overlay"></div>
        <div class="popup_wescle__body modal-box__body">
            <button class="popup_wescle__close modal-box__close" type="button">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 24 24">
                    <path fill="#626262" d="M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29l-4.3 4.29a1 1 0 0 0 0 1.42a1 1 0 0 0 1.42 0l4.29-4.3l4.29 4.3a1 1 0 0 0 1.42 0a1 1 0 0 0 0-1.42z"></path>
                </svg>
            </button>
            <div class="form-call-request">
				<?php echo do_shortcode( '[contact-form-7 id="' . $cf7_id . '"]' ); ?>
            </div>
        </div>
    </div>
	<?php
}
