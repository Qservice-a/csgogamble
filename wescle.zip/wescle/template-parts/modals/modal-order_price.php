<?php
$cf7_id = 0;
if ( Helper::isset_block_content( 'tarif-plan' ) ) {
	$parse_content = parse_blocks( $post->post_content );
	foreach ( $parse_content as $item_block ) {
		if ( $item_block['blockName'] == 'wescle-blocks/tarif-plan' ) {
			$items = $item_block['attrs']['services'] ?? [];
			foreach ( $items as $item ) {
				if ( isset( $item['button_url'] ) && $item['button_url'] == '#modal-order_price' ) {
					$cf7_id = true;
				}
			}
		}
	}
}
elseif ( Helper::is_frontpage_assets() ) {
	if ( get_theme_mod( 'home_prices_enabled' ) || get_theme_mod( 'home_prices2_enabled' ) ) {
		$items = get_theme_mod( 'home_prices_items', [] );
		foreach ( $items as $item ) {
			if ( $item['button_url'] == '#modal-order_price' ) {
				$cf7_id = true;
			}
		}
	}
    elseif ( get_theme_mod( 'home_prices2_enabled' ) ) {
		$items = get_theme_mod( 'home_prices2_items', [] );
		foreach ( $items as $item ) {
			if ( $item['button_url'] == '#modal-order_price' ) {
				$cf7_id = true;
			}
		}
	}
}

if ( true === $cf7_id ) {
	$installed_forms = get_option( THEME_SLUG . '_installed_forms' );
	$cf7_id          = $installed_forms['home_price_tariff'];
}
if ( intval( $cf7_id ) ) {
	?>
    <div class="popup_wescle popup_wescle_modal-order_price modal-box modal-call is-hide" id="modal-order_price" style="opacity: 0">
        <div class="modal-box__overlay"></div>
        <div class="popup_wescle__body modal-box__body">
            <button class="popup_wescle__close modal-box__close" type="button">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" focusable="false" width="1em" height="1em" style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);" preserveaspectratio="xMidYMid meet" viewbox="0 0 24 24">
                    <path fill="#626262" d="M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29l-4.3 4.29a1 1 0 0 0 0 1.42a1 1 0 0 0 1.42 0l4.29-4.3l4.29 4.3a1 1 0 0 0 1.42 0a1 1 0 0 0 0-1.42z"></path>
                </svg>
            </button>
            <div class="form-call-request">
				<?php echo do_shortcode( '[contact-form-7 id="' . $cf7_id . '"]' ); ?>
            </div>
        </div>
    </div>
	<?php
}
