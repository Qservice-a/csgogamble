<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/admin/css/site-settings.css?v=<?php echo wp_get_theme()->get( 'Version' ); ?>"/>
<h1><?php _e( 'Настройки сайта', 'wescle' ); ?></h1>
<?php
if ( isset( $_GET['saved'] ) ) {
	?>
    <div class="notice notice-success is-dismissible">
        <p><strong><?php _e( 'Настройки сохранены', 'wescle' ); ?>.</strong></p>
    </div>
	<?php
}
?>