<?php
$is_special     = get_post_meta( $post->ID, 'is_special', 1 );
$special_label  = get_post_meta( $post->ID, 'is_special_label', 1 );
$class_tab_item = '';
if ( $is_special ) {
	$class_tab_item = ' _recommended';
}

$is_slider_prices = get_post_meta( $post->ID, 'slider_ui', 1 );

$currency          = get_post_meta( $post->ID, 'currency', 1 );
$price_month       = get_post_meta( $post->ID, 'price_month', 1 );
$price_month_after = get_post_meta( $post->ID, 'price_month_after', 1 );
$price_year        = get_post_meta( $post->ID, 'price_year', 1 );
$price_year_after  = get_post_meta( $post->ID, 'price_year_after', 1 );
$price_custom      = get_post_meta( $post->ID, 'price_custom', 1 );

$related_product_id = intval( get_post_meta( $post->ID, 'related_product', 1 ) );
if ( $related_product_id ) {
	$related_product = wc_get_product( $related_product_id );
}

$button_label = get_post_meta( $post->ID, 'label_button', 1 );
$url          = trim( get_post_meta( $post->ID, 'button_url', 1 ) );
if ( ! $url || $url == '#' ) {
	if ( $related_product_id && $related_product ) {
		$url = get_permalink( $related_product_id );
	}
	else {
		$url = '#modal-order_tariff';
	}
}
$url = apply_filters( 'wescle_tariff_button_url', $url, $related_product_id );

$list_info     = get_post_meta( $post->ID, 'wescle_tariff_info', 1 );
$slider_prices = get_post_meta( $post->ID, 'wescle_tariff_slider_prices', 1 );
if ( $is_slider_prices ) {
	$data_range      = [];
	$data_range_link = [];

	$count_slides = count( $slider_prices );
	$loop         = 0;
	foreach ( $slider_prices as $key => $item ) {
		$loop ++;

		if ( $loop == 1 ) {
			$pos       = 0;
			$key_range = 'min';
		}
        elseif ( $loop == $count_slides ) {
			$pos       = 100;
			$key_range = 'max';
		}
		else {
			$pos       = intval( $item['percent'] );
			$key_range = $item['percent'];
		}

		$item                  = array_merge( $item, [ 'pos' => $pos ] );
		$slider_prices[ $key ] = $item;

		$current_pos = intval( $item['value'] );
		$next_pos    = 0;
		if ( isset( $slider_prices[ $key + 1 ] ) ) {
			$next_pos = $slider_prices[ $key + 1 ]['value'];
		}

		if ( $next_pos ) {
			$data_range[ $key_range ] = [
				$current_pos,
				$next_pos
			];
		}
		else {
			$data_range[ $key_range ] = [
				$current_pos
			];
		}

		$data_range_link[ $pos ] = [
			'url'        => $item['url'] ? $item['url'] : '#modal-order_tariff',
			'title'      => $item['label_button'],
			'url_year'   => $item['url_year'] ? $item['url_year'] : '#modal-order_tariff',
			'title_year' => $item['label_button_year'],
		];
	}
}

$btn_flare = $args['btn_flare'] ?? '';

$styles = [];
$color  = get_post_meta( $post->ID, 'color_text', 1 );
if ( $color ) {
	$styles[] = 'color:' . $color;
}
$color = get_post_meta( $post->ID, 'color_bg', 1 );
if ( $color ) {
	$styles[] = 'background-color:' . $color;
}

$style = '';
if ( $styles ) {
	$style = ' style="' . implode( '; ', $styles ) . '"';
}
?>
<div class="wescle-tariffs-item wescle-tariffs-item-<?php echo $post->ID; ?> <?php echo $class_tab_item; ?>"<?php echo $style; ?>>
    <div class="wescle-tariffs-item__header">
        <div class="wescle-tariffs-item__title"><?php echo $post->post_title; ?></div>
		<?php if ( $is_special ) { ?>
            <div class="wescle-tariffs-item__label">
                <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" preserveaspectratio="xMidYMid meet" viewbox="0 0 1024 1024">
                    <path fill="currentColor" d="m908.1 353.1l-253.9-36.9L540.7 86.1c-3.1-6.3-8.2-11.4-14.5-14.5c-15.8-7.8-35-1.3-42.9 14.5L369.8 316.2l-253.9 36.9c-7 1-13.4 4.3-18.3 9.3a32.05 32.05 0 0 0 .6 45.3l183.7 179.1l-43.4 252.9a31.95 31.95 0 0 0 46.4 33.7L512 754l227.1 119.4c6.2 3.3 13.4 4.4 20.3 3.2c17.4-3 29.1-19.5 26.1-36.9l-43.4-252.9l183.7-179.1c5-4.9 8.3-11.3 9.3-18.3c2.7-17.5-9.5-33.7-27-36.3z"></path>
                </svg>
				<?php if ( $special_label ) { ?>
                    <span><?php echo $special_label; ?></span>
				<?php } ?>
            </div>
		<?php } ?>
    </div>
	<?php if ( $post->post_content ) { ?>
        <div class="wescle-tariffs-item__text"><?php echo $post->post_content; ?></div>
	<?php } ?>

	<?php if ( $is_slider_prices && $slider_prices ) { ?>
		<?php
		$slider_ui_min_text   = get_post_meta( $post->ID, 'slider_ui_min_text', 1 );
		$slider_ui_max_text   = get_post_meta( $post->ID, 'slider_ui_max_text', 1 );
		$slider_ui_month_text = get_post_meta( $post->ID, 'slider_ui_month_text', 1 );
		$slider_ui_year_text  = get_post_meta( $post->ID, 'slider_ui_year_text', 1 );
		?>
        <div class="wescle-tariffs-range">
            <div class="wescle-tariffs-item__prices">
				<?php foreach ( $slider_prices as $slider_item ) { ?>
                    <div class="wescle-tariffs-item__price _active" data-pos="<?php echo $slider_item['pos']; ?>">
                        <span class="wescle-tariffs-item__price-currency"><?php echo $slider_item['price_currency']; ?></span>
                        <span class="wescle-tariffs-item__price-count">
                            <span class="_monthly"><?php echo $slider_item['price_month']; ?></span>
                            <span class="_annually"><?php echo $slider_item['price_year']; ?></span>
                        </span>
                        <span class="wescle-tariffs-item__price-text"
                              data-text-monthly="<?php echo $slider_item['price_month_after']; ?>"
                              data-text-annually="<?php echo $slider_item['price_year_after']; ?>"><?php echo $slider_item['price_month_after']; ?></span>
                    </div>
				<?php } ?>
            </div>
            <div class="wescle-tariffs-range__minmax">
                <span class="wescle-tariffs-range__min"><?php echo $slider_ui_min_text; ?></span>
                <span class="wescle-tariffs-range__max"><?php echo $slider_ui_max_text; ?></span>
            </div>
            <div class="wescle-tariffs-range__slider"
                 data-start="<?php echo $data_range['min'][0]; ?>" data-range="<?php echo htmlspecialchars( json_encode( $data_range ), ENT_QUOTES, 'UTF-8' ); ?>"
                 data-range-link="<?php echo htmlspecialchars( json_encode( $data_range_link ), ENT_QUOTES, 'UTF-8' ); ?>">
            </div>
            <div class="wescle-tariffs-range__value">
                <strong>0</strong><span><?php echo $slider_ui_month_text; ?></span>
            </div>
        </div>
        <div class="wescle-tariffs-item__links">
			<?php foreach ( $data_range_link as $key => $item ) { ?>
                <div class="wescle-tariffs-item__link _active" data-pos="<?php echo $key; ?>">
					<?php if ( $item['title'] ) { ?>
                        <div class="_monthly">
                            <?php $url = $item['url']; ?>
	                        <?php if ( $url == '#modal-order_tariff' ) { ?>
                                <a class="tariff-tab-item__btn btn btn-main btn-main_blue _popup-link <?php echo $btn_flare; ?>" data-name="<?php echo esc_attr( $post->post_title ); ?>" href="<?php echo $url; ?>"><span><?php echo $item['title']; ?></span></a>
	                        <?php } elseif ( Helper::is_external_url( $url ) ) { ?>
                                <a class="tariff-tab-item__btn btn btn-main btn-main_blue <?php echo $btn_flare; ?>" href="<?php echo $url; ?>" target="_blank" rel="noopener noreferrer"><span><?php echo $item['title']; ?></span></a>
	                        <?php } else { ?>
                                <a class="tariff-tab-item__btn btn btn-main btn-main_blue <?php echo $btn_flare; ?>" href="<?php echo $url; ?>"><span><?php echo $item['title']; ?></span></a>
	                        <?php } ?>
                        </div>
                    <?php } ?>
                    <?php if ( $item['title_year'] ) { ?>
                        <div class="_annually">
	                        <?php $url = $item['url_year']; ?>
	                        <?php if ( $url == '#modal-order_tariff' ) { ?>
                                <a class="tariff-tab-item__btn btn btn-main btn-main_blue _popup-link <?php echo $btn_flare; ?>" data-name="<?php echo esc_attr( $post->post_title ); ?>" href="<?php echo $url; ?>"><span><?php echo $item['title']; ?></span></a>
	                        <?php } elseif ( Helper::is_external_url( $url ) ) { ?>
                                <a class="tariff-tab-item__btn btn btn-main btn-main_blue <?php echo $btn_flare; ?>" href="<?php echo $url; ?>" target="_blank" rel="noopener noreferrer"><span><?php echo $item['title']; ?></span></a>
	                        <?php } else { ?>
                                <a class="tariff-tab-item__btn btn btn-main btn-main_blue <?php echo $btn_flare; ?>" href="<?php echo $url; ?>"><span><?php echo $item['title']; ?></span></a>
	                        <?php } ?>
                        </div>
					<?php } ?>
                </div>
			<?php } ?>
        </div>
	<?php } else { ?>
		<?php if ( $price_custom ) { ?>
            <div class="wescle-tariffs-item__price-clear"><span><?php echo $price_custom; ?></span></div>
		<?php } else { ?>
            <div class="wescle-tariffs-item__price" data-per-month="<?php echo esc_attr( $price_month ); ?>" data-per-month-text="<?php echo esc_attr( $price_month_after ); ?>" data-annually="<?php echo esc_attr( $price_year ); ?>" data-annually-text="<?php echo esc_attr( $price_year_after ); ?>">
                <span class="wescle-tariffs-item__price-currency"><?php echo $currency; ?></span>
                <span class="wescle-tariffs-item__price-count"><?php echo $price_month; ?></span>
				<?php if ( $price_month_after ) { ?>
                    <span class="wescle-tariffs-item__price-text" data-text-monthly="<?php echo esc_attr( $price_month_after ); ?>" data-text-annually="<?php echo esc_attr( $price_year_after ); ?>"><?php echo $price_month_after; ?></span>
				<?php } ?>
            </div>
		<?php } ?>
		<?php if ( $url && $button_label ) { ?>
			<?php if ( $url == '#modal-order_tariff' ) { ?>
                <a class="tariff-tab-item__btn btn btn-main btn-main_blue _popup-link <?php echo $btn_flare; ?>" data-name="<?php echo esc_attr( $post->post_title ); ?>" href="<?php echo $url; ?>"><span><?php echo $button_label; ?></span></a>
			<?php } elseif ( Helper::is_external_url( $url ) ) { ?>
                <a class="tariff-tab-item__btn btn btn-main btn-main_blue <?php echo $btn_flare; ?>" href="<?php echo $url; ?>" target="_blank" rel="noopener noreferrer"><span><?php echo $button_label; ?></span></a>
			<?php } else { ?>
                <a class="tariff-tab-item__btn btn btn-main btn-main_blue <?php echo $btn_flare; ?>" href="<?php echo $url; ?>"><span><?php echo $button_label; ?></span></a>
			<?php } ?>
		<?php } ?>
	<?php } ?>
	<?php if ( $list_info ) { ?>
        <ul class="wescle-tariffs-item__list">
			<?php foreach ( $list_info as $item ) { ?>
                <li>
                    <span class="wescle-tariffs-item__point"><?php echo $item['title']; ?></span>
					<?php if ( $item['type'] === 'minus' ) { ?>
                        <span class="wescle-tariffs-item__icon _unchecked">
                            <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" preserveaspectratio="xMidYMid meet" viewbox="0 0 48 48">
                              <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="4" d="m8 8l32 32M8 40L40 8"></path>
                            </svg>
                        </span>
					<?php } elseif ( $item['type'] === 'plus' ) { ?>
                        <span class="wescle-tariffs-item__icon _checked">
                            <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" preserveaspectratio="xMidYMid meet" viewbox="0 0 24 24">
                              <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m4 12l6 6L20 6"></path>
                            </svg>
                        </span>
					<?php } else { ?>
                        <span class="wescle-tariffs-item__value"><?php echo $item['text']; ?></span>
					<?php } ?>
                </li>
			<?php } ?>
        </ul>
	<?php } ?>
</div>