<div class="wescle-livesearch__item wescle-livesearch__item_all">
    <a href="<?php echo $args['url']; ?>"><?php _e( 'Смотреть все результаты', 'wescle' ); ?></a>
</div>