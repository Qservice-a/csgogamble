<?php
$btn_flare        = $args['btn_flare'] ?? '';
$block_attributes = $args['block_attributes'] ?? [];

if ( $block_attributes ) {
	$price_label_first = $block_attributes['priceTitleFirst'] ?? Helper::get_default_theme_data( 'home_tariff_price_first' );
	$price_label_two   = $block_attributes['priceTitleSecond'] ?? Helper::get_default_theme_data( 'home_tariff_price_two' );
}
else {
	$price_label_first = get_theme_mod( 'home_tariff_price_first', Helper::get_default_theme_data( 'home_tariff_price_first' ) );
	$price_label_two   = get_theme_mod( 'home_tariff_price_two', Helper::get_default_theme_data( 'home_tariff_price_two' ) );
}

$is_price_toggle = false;

$posts_tariff = get_posts( [
	'post_type'      => 'tariff_wescle',
	'posts_per_page' => - 1,
	'orderby'        => [ 'menu_order' => 'ASC', 'date' => 'DESC' ]
] );
foreach ( $posts_tariff as $post_tariff ) {
	$price_month = get_post_meta( $post_tariff->ID, 'price_month', 1 );
	$price_year  = get_post_meta( $post_tariff->ID, 'price_year', 1 );
	if ( $price_month && $price_year ) {
		$is_price_toggle = true;
	}

	$slider_prices = get_post_meta( $post_tariff->ID, 'wescle_tariff_slider_prices', 1 );
	if ( $slider_prices ) {
		foreach ( $slider_prices as $key => $item ) {
			if ( $item['price_month'] && $item['price_year'] ) {
				$is_price_toggle = true;
			}
		}
	}

	if ( $is_price_toggle ) {
		break;
	}
}

$terms = get_terms( [
	'taxonomy' => 'tariffcat_wescle'
] );
?>
<div class="_tabs">
    <div class="wescle-tariffs__header">
		<?php if ( $terms && count( $terms ) > 1 ) { ?>
            <div class="_tabs-nav">
				<?php foreach ( $terms as $key_term => $term ) { ?>
					<?php $tab_class = $key_term === 0 ? ' _active' : ''; ?>
                    <button class="btn btn-main _tabs-item<?php echo $tab_class; ?>" type="button"><span><?php echo $term->name; ?></span></button>
				<?php } ?>
            </div>
		<?php } ?>
		<?php if ( $is_price_toggle ) { ?>
            <div class="wescle-tariffs__period">
                <label class="_price-toggle">
                    <input type="checkbox" name="price-toggle">
                    <div><span class="_unchecked"><?php echo $price_label_first; ?></span>
                        <div class="_toggle"></div>
                        <span class="_checked"><?php echo $price_label_two; ?></span>
                    </div>
                </label>
            </div>
		<?php } ?>
    </div>
	<?php
	if ( ! $terms ) {
		$terms = [ 0 ];
	}
	?>
    <div class="_tabs-body">
		<?php foreach ( $terms as $key_term => $term ) { ?>
			<?php
			$tab_class = $key_term === 0 ? ' _active' : '';
			if ( $term !== 0 ) {
				$posts_tariff = get_posts( [
					'post_type'      => 'tariff_wescle',
					'posts_per_page' => - 1,
					'orderby'        => [ 'menu_order' => 'ASC', 'date' => 'DESC' ],
					'tax_query'      => [
						[
							'taxonomy' => 'tariffcat_wescle',
							'terms'    => [ $term->term_id ],
						]
					],
				] );
			}
			?>
            <div class="_tabs-block<?php echo $tab_class; ?>">
                <div class="wescle-tariffs__content">
					<?php
					foreach ( $posts_tariff as $post ) {
						setup_postdata( $post );

						get_template_part( 'template-parts/content/tariff-item', '', [ 'btn_flare' => $btn_flare ] );
					}
					wp_reset_postdata();
					?>
                </div>
            </div>
		<?php } ?>
    </div>
</div>