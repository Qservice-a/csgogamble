<?php
$text = '';
if ( get_theme_mod( 'header_search_ajax_short_excerpt', true ) ) {
	if ( $post->post_excerpt ) {
		$text = $post->post_excerpt;
	}
	else {
		$text = wp_strip_all_tags( $post->post_content );
	}
	$text = Helper::short_string( $text, 100 );
}
?>
<a href="<?php echo get_permalink(); ?>" class="wescle-livesearch__item">
    <div class="wescle-livesearch__image">
		<?php echo get_the_post_thumbnail( $post, 'medium' ); ?>
    </div>
    <div class="wescle-livesearch__title_text">
        <div class="livesearch-title"><?php echo get_the_title(); ?></div>
		<?php if ( $text ) { ?>
            <div class="livesearch-text"><?php echo $text; ?></div>
		<?php } ?>
    </div>
</a>