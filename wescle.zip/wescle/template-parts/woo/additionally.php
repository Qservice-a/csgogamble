<?php
$items = $args['data_additionally'];
if ( ! $items ) {
	return;
}
?>
<div class="product-additionally">
    <div class="product-additionally__grid">
		<?php foreach ( $items as $item ) { ?>
			<?php if ( $item['title'] || $item['text'] ) { ?>
                <div class="product-additionally-item">
					<?php if ( $item['title'] ) { ?>
                        <div class="product-additionally-item__title"><?php echo $item['title']; ?></div>
					<?php } ?>
					<?php if ( $item['text'] ) { ?>
                        <div class="product-additionally-item__text"><?php echo nl2br( $item['text'] ); ?></div>
					<?php } ?>
                </div>
			<?php } ?>
		<?php } ?>
    </div>
</div>