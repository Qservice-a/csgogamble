<?php
$args    = get_query_var( 'template_args' );
$options = $args['instance'];
if ( ! $options['cf7_id'] ) {
	return;
}
?>
<div class="newsletter__form form-newsletter">
	<?php echo do_shortcode( '[contact-form-7 id="' . $options['cf7_id'] . '"]' ); ?>
	<?php if ( $options['text_after_form'] ) { ?>
        <div class="newsletter__info"><?php echo nl2br( $options['text_after_form'] ); ?></div>
	<?php } ?>
</div>