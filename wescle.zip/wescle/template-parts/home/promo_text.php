<?php
$block_enabled = get_theme_mod( 'home_text_before_slider_enabled', true );
if ( ! $block_enabled ) {
	return;
}

$text = get_theme_mod( 'home_text_before_slider', '' );

$style_bg = '';
if ( $color_bg = get_theme_mod( 'home_before_slider_color_bg' ) ) {
	$style_bg = 'style="background-color:' . $color_bg . ';"';
}
if ( $text ) {
	$bg_img = wescle_home_block_bg_image( 'home_before_slider_image_bg' );

	$section_class    = '';
	$section_position = get_theme_mod( 'home_before_slider_position_content', 'default' );
	if ( 'default' != $section_position ) {
		$section_class .= ' _section-' . $section_position;
	}

	echo '<div class="text_before_promo' . $section_class . '" ' . $style_bg . '>' . $bg_img . '<div class="container"><div class="col1">' . wpautop( do_shortcode( $text ) ) . '</div></div></div>';
}