<?php if ( current_user_can( 'administrator' ) ) { ?>
    <div class="promo promo_v2">
        <div class="container">
			<?php printf( __( 'Это уведомление показывается только администратору. <br/>Для настройки "Первого экрана" перейдите в пункт меню <a href="%s">Внешний вид - Настроить</a>, потом выберите "<strong>Конструктор главной страницы</strong>"', 'wescle' ), admin_url( 'customize.php' ) ); ?>
        </div>
    </div>
<?php } ?>