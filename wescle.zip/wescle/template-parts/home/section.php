<?php
if ( isset( $args['home_blocks_posts'] ) ) {
	$home_blocks_posts       = $args['home_blocks_posts'];
	$choices_visibility_meta = [
		'category' => 'category',
		'excerpt'  => 'excerpt',
		'author'   => 'author',
		'date'     => 'date',
		'comments' => 'comments',
		'views'    => 'views',
	];
}
else {
	$home_blocks_posts       = get_theme_mod( 'home_blocks_posts', [] );
	$choices_visibility_meta = Helper::get_post_card_meta();
}

foreach ( $home_blocks_posts as $key_block => $block ) {

	$block_on = isset( $block['block_on'] ) ? $block['block_on'] : '';
	if ( $block_on === false ) {
		continue;
	}

	$code_advt = $block['block_advt'];
	if ( $code_advt ) {
		set_query_var( 'template_args', [ 'code' => $code_advt, 'container' => false ] );
		get_template_part( 'template-parts/section/advt', '' );
	}

	$block_title       = str_replace( '%', '%%', $block['block_title'] );
	$block_title_type  = $block['block_title_type'];
	$block_text        = isset( $block['block_text'] ) ? nl2br( $block['block_text'] ) : '';
	$post_card_type    = $block['block_post_card_type'] ? $block['block_post_card_type'] : 'default';
	$post_card_opacity = $block['block_post_card_opacity'] ?? 100;
	$post_card_columns = $block['block_post_card_columns'] ?? 3;
	$block_type        = 'recommended';

	if ( $post_card_type == 'vertical' || $post_card_type == 'featured' ) {
		$block_type = 'featured';
	}
	elseif ( $post_card_type == 'horizontal' || $post_card_type == 'latest' ) {
		$block_type = 'latest';
	}
	elseif ( $post_card_type == 'horizontal2' || $post_card_type == 'latest2' ) {
		$block_type = 'latest2';
	}

	$post_card_meta = [];
	foreach ( $choices_visibility_meta as $key => $val ) {
		$post_card_meta[ $key ] = $key;
	}

	foreach ( $choices_visibility_meta as $key => $val ) {
		if ( isset( $block[ 'visibility_' . $key ] ) && ! $block[ 'visibility_' . $key ] ) {
			unset( $post_card_meta[ $key ] );
		}
	}

	$posts_per_page = absint( $block['block_limit'] );
	if ( $posts_per_page > 40 ) {
		$posts_per_page = 0;
	}

	if ( $posts_per_page == 0 ) {
		$posts_per_page = 3;
	}

	$args = [
		'post_type'        => 'post',
		'posts_per_page'   => $posts_per_page,
		'tax_query'        => [],
		'post__in'         => '',
		'suppress_filters' => false
	];

	$posts_orderby = $block['block_posts_orderby'];
	if ( $posts_orderby == 'views' ) {
		if ( Helper::is_plugin_active( 'post-views-counter/post-views-counter.php' ) ) {
			$args['suppress_filters'] = false;
			$args['orderby']          = 'post_views';
			$args['fields']           = '';
			$args['meta_key']         = '';
		}
		else {
			$args['orderby']  = 'meta_value_num';
			$args['order']    = 'DESC';
			$args['meta_key'] = 'views';
		}
	}
	else {
		$args['orderby'] = $posts_orderby;
	}

	$cat_include   = $block['block_category'];
	$posts_include = $block['block_posts'];

	if ( $posts_include && $posts_include[0] ) {
		$args['post__in']       = $posts_include;
		$args['posts_per_page'] = count( $posts_include );
	}
	elseif ( $cat_include && $cat_include[0] ) {
		$args['tax_query'][] = [
			'taxonomy' => 'category',
			'terms'    => $cat_include,
		];
	}

	/*if ( $code_advt && ! $cat_include && ! $posts_include ) {
		continue;
	}*/

	$args = apply_filters( 'block_posts_args', $args, $block );

	$posts_section = get_posts( $args );
	if ( $posts_section ) {
		$link_url  = $block['block_posts_link_custom'] ?? '';
		$link_text = $block['block_posts_link_text'] ?? '';
		if ( ! $link_url ) {
			$link_url_id = $block['block_posts_link_id'] ?? '';
			if ( $link_url_id ) {
				$link_url = get_term_link( intval( $link_url_id ), 'category' );
				if ( ! $link_text ) {
					$link_text = get_term_by( 'id', intval( $link_url_id ), 'category' )->name;
				}
			}
		}

		$data = [
			'posts'             => $posts_section,
			'block_title'       => $block_title,
			'block_title_type'  => $block_title_type,
			'block_text'        => $block_text,
			'post_card_type'    => $post_card_type,
			'post_card_opacity' => $post_card_opacity,
			'post_card_columns' => $post_card_columns,
			'key_block'         => $key_block,
			'post_card_meta'    => $post_card_meta,
			'posts_per_page'    => $posts_per_page,
			'link_text'         => $link_text,
			'link_url'          => $link_url,
		];

		set_query_var( 'template_args', $data );
		get_template_part( 'template-parts/section/section', $block_type );
	}
}