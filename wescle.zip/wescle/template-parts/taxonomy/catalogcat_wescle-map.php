<?php get_header(); ?>

<?php get_template_part( 'template-parts/archive/title' ); ?>

<?php
$term = get_queried_object();

$code = get_theme_mod( 'reklama_archive_before_content', '' );
if ( $code ) {
	set_query_var( 'template_args', [ 'code' => $code ] );
	get_template_part( 'template-parts/section/advt', '' );
}
$class_three_in_row = get_theme_mod( 'catalog_archive_three_in_row' ) ? ' _3' : '';
?>
    <div class="content">
        <div class="container">
            <div class="row content__row">
                <div class="col content__col content__col_big">
                    <div class="content__body">
                        <div class="category-catalog-container">
                            <div class="category-catalog-grid">
								<?php get_template_part( 'template-parts/archive/catalog-category_filters' ); ?>
                                <div class="_tabs-block" data-number="0">
                                    <div class="wescle-transport__grid<?php echo $class_three_in_row; ?>">
										<?php
										while ( have_posts() ) : the_post();
											get_template_part( 'template-parts/content/catalog-item' );
										endwhile;
										?>
                                    </div>
									<?php wescle_paginate_links(); ?>
                                </div>
                            </div>
                            <div class="category-catalog-map">
								<?php echo do_shortcode( '[catalog_map]' ); ?>
                            </div>
                        </div>

						<?php
						if ( ! is_paged() ) {
							$description_bottom = get_term_meta( get_queried_object_id(), 'description_bottom', 1 );
							if ( $description_bottom ) {
								?>
                                <div class="content-bottom entry-content text section-post__editor">
									<?php
									if ( $description_bottom ) {
										echo do_shortcode( shortcode_unautop( wpautop( $description_bottom ) ) );
									}
									?>
                                </div>
								<?php
							}
						}
						?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
$code = get_theme_mod( 'reklama_archive_after_content', '' );
if ( $code ) {
	set_query_var( 'template_args', [ 'code' => $code ] );
	get_template_part( 'template-parts/section/advt', '' );
}
?>

<?php get_footer(); ?>